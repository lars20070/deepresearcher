# deepresearcher

fully local web research and report writing assistant
