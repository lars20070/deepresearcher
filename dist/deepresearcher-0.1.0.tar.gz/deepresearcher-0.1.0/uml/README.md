Generate UML class diagrams with `pyreverse` from the `pylint` package.
```bash
# brew install graphviz
uv run pyreverse -o png -A -k -d ./uml ./src/deepresearcher
```
