"""
deepresearcher public interface
"""

from .logger import logger  # noqa: I001

__all__ = [
    "logger",
]
