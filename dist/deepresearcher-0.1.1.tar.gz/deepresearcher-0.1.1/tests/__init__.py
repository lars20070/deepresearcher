"""
tests initialization
"""

__all__ = []
